$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+812762+'&oi='+401+'&ot=1&&url='+window.location, function(json){})    

});